const express = require('express');
const cors = require('cors');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 10000;

// Middleware
app.use(cors());
app.use(express.json());

// Servir le frontend en production
app.use(express.static(path.join(__dirname, '../frontend/build')));

// Initialisation de la base de données
const db = new Database(path.join(__dirname, 'database.sqlite'));

// Création des tables
db.exec(`
  -- Table des paramètres (mot de passe admin)
  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );

  -- Table des enfants
  CREATE TABLE IF NOT EXISTS children (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    avatar TEXT NOT NULL,
    points INTEGER DEFAULT 0,
    color TEXT DEFAULT '#FF6B9D',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  -- Table des tâches
  CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    points INTEGER NOT NULL,
    category TEXT DEFAULT 'maison',
    icon TEXT DEFAULT '📋',
    frequency TEXT DEFAULT 'quotidienne',
    active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  -- Table des récompenses
  CREATE TABLE IF NOT EXISTS rewards (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    cost INTEGER NOT NULL,
    icon TEXT DEFAULT '🎁',
    description TEXT,
    active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  -- Table des tâches en attente de validation
  CREATE TABLE IF NOT EXISTS pending_tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    child_id INTEGER NOT NULL,
    task_id INTEGER NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (child_id) REFERENCES children(id) ON DELETE CASCADE,
    FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE
  );

  -- Table de l'historique des tâches validées
  CREATE TABLE IF NOT EXISTS task_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    child_id INTEGER NOT NULL,
    task_id INTEGER NOT NULL,
    task_name TEXT NOT NULL,
    points_earned INTEGER NOT NULL,
    validated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (child_id) REFERENCES children(id) ON DELETE CASCADE
  );

  -- Table de l'historique des récompenses réclamées
  CREATE TABLE IF NOT EXISTS reward_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    child_id INTEGER NOT NULL,
    reward_id INTEGER NOT NULL,
    reward_name TEXT NOT NULL,
    points_spent INTEGER NOT NULL,
    claimed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (child_id) REFERENCES children(id) ON DELETE CASCADE
  );
`);

// Initialisation du mot de passe admin par défaut (1234)
const initAdminPassword = () => {
  const existing = db.prepare('SELECT value FROM settings WHERE key = ?').get('admin_pin');
  if (!existing) {
    const hashedPin = bcrypt.hashSync('1234', 10);
    db.prepare('INSERT INTO settings (key, value) VALUES (?, ?)').run('admin_pin', hashedPin);
    console.log('Mot de passe admin initialisé (par défaut: 1234)');
  }
};

// Données initiales
const initDefaultData = () => {
  const childCount = db.prepare('SELECT COUNT(*) as count FROM children').get();
  if (childCount.count === 0) {
    const insertChild = db.prepare('INSERT INTO children (name, avatar, points, color) VALUES (?, ?, ?, ?)');
    insertChild.run('Emma', '👧', 85, '#FF6B9D');
    insertChild.run('Lucas', '👦', 120, '#4ECDC4');
    console.log('Enfants par défaut créés');
  }

  const taskCount = db.prepare('SELECT COUNT(*) as count FROM tasks').get();
  if (taskCount.count === 0) {
    const insertTask = db.prepare('INSERT INTO tasks (name, points, category, icon, frequency) VALUES (?, ?, ?, ?, ?)');
    insertTask.run('Ranger sa chambre', 15, 'maison', '🏠', 'quotidienne');
    insertTask.run('Vider les poubelles', 10, 'maison', '🗑️', 'quotidienne');
    insertTask.run('Faire ses devoirs', 20, 'école', '📚', 'quotidienne');
    insertTask.run('Mettre la table', 5, 'maison', '🍽️', 'quotidienne');
    insertTask.run('Se brosser les dents', 5, 'hygiène', '🪥', 'quotidienne');
    insertTask.run('Aider à faire la vaisselle', 15, 'maison', '🧽', 'ponctuelle');
    insertTask.run('Lire 30 minutes', 15, 'école', '📖', 'quotidienne');
    insertTask.run('Ranger ses jouets', 10, 'maison', '🧸', 'quotidienne');
    console.log('Tâches par défaut créées');
  }

  const rewardCount = db.prepare('SELECT COUNT(*) as count FROM rewards').get();
  if (rewardCount.count === 0) {
    const insertReward = db.prepare('INSERT INTO rewards (name, cost, icon, description) VALUES (?, ?, ?, ?)');
    insertReward.run('Choisir le film du soir', 50, '🎬', 'Tu choisis le film pour la soirée cinéma !');
    insertReward.run('Un t-shirt', 100, '👕', 'Un nouveau t-shirt de ton choix');
    insertReward.run('Sortie glace', 150, '🍦', 'Une sortie pour manger une glace');
    insertReward.run('Jouet surprise', 300, '🎁', 'Un jouet de ton choix !');
    insertReward.run('30 min de jeu vidéo', 40, '🎮', '30 minutes de jeu vidéo en plus');
    insertReward.run('Soirée pyjama', 200, '🌙', 'Inviter un ami pour une soirée pyjama');
    console.log('Récompenses par défaut créées');
  }
};

initAdminPassword();
initDefaultData();

// ============== ROUTES API ==============

// --- Authentication ---
app.post('/api/auth/verify-pin', (req, res) => {
  const { pin } = req.body;
  const stored = db.prepare('SELECT value FROM settings WHERE key = ?').get('admin_pin');
  
  if (stored && bcrypt.compareSync(pin, stored.value)) {
    res.json({ success: true });
  } else {
    res.status(401).json({ success: false, error: 'Code PIN incorrect' });
  }
});

app.post('/api/auth/change-pin', (req, res) => {
  const { currentPin, newPin } = req.body;
  const stored = db.prepare('SELECT value FROM settings WHERE key = ?').get('admin_pin');
  
  if (!stored || !bcrypt.compareSync(currentPin, stored.value)) {
    return res.status(401).json({ success: false, error: 'Code PIN actuel incorrect' });
  }
  
  if (!newPin || newPin.length < 4) {
    return res.status(400).json({ success: false, error: 'Le nouveau PIN doit contenir au moins 4 caractères' });
  }
  
  const hashedPin = bcrypt.hashSync(newPin, 10);
  db.prepare('UPDATE settings SET value = ? WHERE key = ?').run(hashedPin, 'admin_pin');
  
  res.json({ success: true, message: 'Code PIN modifié avec succès' });
});

// --- Children ---
app.get('/api/children', (req, res) => {
  const children = db.prepare('SELECT * FROM children ORDER BY name').all();
  res.json(children);
});

app.post('/api/children', (req, res) => {
  const { name, avatar, points = 0, color = '#FF6B9D' } = req.body;
  const result = db.prepare('INSERT INTO children (name, avatar, points, color) VALUES (?, ?, ?, ?)').run(name, avatar, points, color);
  const child = db.prepare('SELECT * FROM children WHERE id = ?').get(result.lastInsertRowid);
  res.json(child);
});

app.put('/api/children/:id', (req, res) => {
  const { id } = req.params;
  const { name, avatar, points, color } = req.body;
  db.prepare('UPDATE children SET name = ?, avatar = ?, points = ?, color = ? WHERE id = ?').run(name, avatar, points, color, id);
  const child = db.prepare('SELECT * FROM children WHERE id = ?').get(id);
  res.json(child);
});

app.delete('/api/children/:id', (req, res) => {
  const { id } = req.params;
  db.prepare('DELETE FROM children WHERE id = ?').run(id);
  res.json({ success: true });
});

app.post('/api/children/:id/adjust-points', (req, res) => {
  const { id } = req.params;
  const { amount } = req.body;
  db.prepare('UPDATE children SET points = MAX(0, points + ?) WHERE id = ?').run(amount, id);
  const child = db.prepare('SELECT * FROM children WHERE id = ?').get(id);
  res.json(child);
});

// --- Tasks ---
app.get('/api/tasks', (req, res) => {
  const tasks = db.prepare('SELECT * FROM tasks WHERE active = 1 ORDER BY name').all();
  res.json(tasks);
});

app.post('/api/tasks', (req, res) => {
  const { name, points, category = 'maison', icon = '📋', frequency = 'quotidienne' } = req.body;
  const result = db.prepare('INSERT INTO tasks (name, points, category, icon, frequency) VALUES (?, ?, ?, ?, ?)').run(name, points, category, icon, frequency);
  const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(result.lastInsertRowid);
  res.json(task);
});

app.put('/api/tasks/:id', (req, res) => {
  const { id } = req.params;
  const { name, points, category, icon, frequency } = req.body;
  db.prepare('UPDATE tasks SET name = ?, points = ?, category = ?, icon = ?, frequency = ? WHERE id = ?').run(name, points, category, icon, frequency, id);
  const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(id);
  res.json(task);
});

app.delete('/api/tasks/:id', (req, res) => {
  const { id } = req.params;
  db.prepare('UPDATE tasks SET active = 0 WHERE id = ?').run(id);
  res.json({ success: true });
});

// --- Rewards ---
app.get('/api/rewards', (req, res) => {
  const rewards = db.prepare('SELECT * FROM rewards WHERE active = 1 ORDER BY cost').all();
  res.json(rewards);
});

app.post('/api/rewards', (req, res) => {
  const { name, cost, icon = '🎁', description = '' } = req.body;
  const result = db.prepare('INSERT INTO rewards (name, cost, icon, description) VALUES (?, ?, ?, ?)').run(name, cost, icon, description);
  const reward = db.prepare('SELECT * FROM rewards WHERE id = ?').get(result.lastInsertRowid);
  res.json(reward);
});

app.put('/api/rewards/:id', (req, res) => {
  const { id } = req.params;
  const { name, cost, icon, description } = req.body;
  db.prepare('UPDATE rewards SET name = ?, cost = ?, icon = ?, description = ? WHERE id = ?').run(name, cost, icon, description, id);
  const reward = db.prepare('SELECT * FROM rewards WHERE id = ?').get(id);
  res.json(reward);
});

app.delete('/api/rewards/:id', (req, res) => {
  const { id } = req.params;
  db.prepare('UPDATE rewards SET active = 0 WHERE id = ?').run(id);
  res.json({ success: true });
});

// --- Pending Tasks ---
app.get('/api/pending-tasks', (req, res) => {
  const pending = db.prepare(`
    SELECT pt.*, t.name as task_name, t.points as task_points, t.icon as task_icon,
           c.name as child_name, c.avatar as child_avatar
    FROM pending_tasks pt
    JOIN tasks t ON pt.task_id = t.id
    JOIN children c ON pt.child_id = c.id
    ORDER BY pt.created_at DESC
  `).all();
  res.json(pending);
});

app.post('/api/pending-tasks', (req, res) => {
  const { child_id, task_id } = req.body;
  const result = db.prepare('INSERT INTO pending_tasks (child_id, task_id) VALUES (?, ?)').run(child_id, task_id);
  const pending = db.prepare(`
    SELECT pt.*, t.name as task_name, t.points as task_points, t.icon as task_icon
    FROM pending_tasks pt
    JOIN tasks t ON pt.task_id = t.id
    WHERE pt.id = ?
  `).get(result.lastInsertRowid);
  res.json(pending);
});

app.post('/api/pending-tasks/:id/validate', (req, res) => {
  const { id } = req.params;
  
  const pending = db.prepare(`
    SELECT pt.*, t.name as task_name, t.points as task_points
    FROM pending_tasks pt
    JOIN tasks t ON pt.task_id = t.id
    WHERE pt.id = ?
  `).get(id);
  
  if (!pending) {
    return res.status(404).json({ error: 'Tâche non trouvée' });
  }
  
  // Ajouter les points à l'enfant
  db.prepare('UPDATE children SET points = points + ? WHERE id = ?').run(pending.task_points, pending.child_id);
  
  // Enregistrer dans l'historique
  db.prepare('INSERT INTO task_history (child_id, task_id, task_name, points_earned) VALUES (?, ?, ?, ?)').run(
    pending.child_id, pending.task_id, pending.task_name, pending.task_points
  );
  
  // Supprimer de la liste des tâches en attente
  db.prepare('DELETE FROM pending_tasks WHERE id = ?').run(id);
  
  const child = db.prepare('SELECT * FROM children WHERE id = ?').get(pending.child_id);
  res.json({ success: true, child });
});

app.post('/api/pending-tasks/:id/reject', (req, res) => {
  const { id } = req.params;
  db.prepare('DELETE FROM pending_tasks WHERE id = ?').run(id);
  res.json({ success: true });
});

// --- Claim Reward ---
app.post('/api/rewards/:id/claim', (req, res) => {
  const { id } = req.params;
  const { child_id } = req.body;
  
  const reward = db.prepare('SELECT * FROM rewards WHERE id = ?').get(id);
  const child = db.prepare('SELECT * FROM children WHERE id = ?').get(child_id);
  
  if (!reward || !child) {
    return res.status(404).json({ error: 'Récompense ou enfant non trouvé' });
  }
  
  if (child.points < reward.cost) {
    return res.status(400).json({ error: 'Points insuffisants' });
  }
  
  // Déduire les points
  db.prepare('UPDATE children SET points = points - ? WHERE id = ?').run(reward.cost, child_id);
  
  // Enregistrer dans l'historique
  db.prepare('INSERT INTO reward_history (child_id, reward_id, reward_name, points_spent) VALUES (?, ?, ?, ?)').run(
    child_id, id, reward.name, reward.cost
  );
  
  const updatedChild = db.prepare('SELECT * FROM children WHERE id = ?').get(child_id);
  res.json({ success: true, child: updatedChild, reward });
});

// --- History ---
app.get('/api/history/tasks/:child_id', (req, res) => {
  const { child_id } = req.params;
  const history = db.prepare('SELECT * FROM task_history WHERE child_id = ? ORDER BY validated_at DESC LIMIT 50').all(child_id);
  res.json(history);
});

app.get('/api/history/rewards/:child_id', (req, res) => {
  const { child_id } = req.params;
  const history = db.prepare('SELECT * FROM reward_history WHERE child_id = ? ORDER BY claimed_at DESC LIMIT 50').all(child_id);
  res.json(history);
});

// --- Stats ---
app.get('/api/stats', (req, res) => {
  const totalTasks = db.prepare('SELECT COUNT(*) as count FROM task_history').get();
  const totalRewards = db.prepare('SELECT COUNT(*) as count FROM reward_history').get();
  const totalPoints = db.prepare('SELECT SUM(points) as total FROM children').get();
  const topTask = db.prepare(`
    SELECT task_name, COUNT(*) as count 
    FROM task_history 
    GROUP BY task_name 
    ORDER BY count DESC 
    LIMIT 1
  `).get();
  
  res.json({
    totalTasksCompleted: totalTasks.count,
    totalRewardsClaimed: totalRewards.count,
    totalPointsEarned: totalPoints.total || 0,
    mostPopularTask: topTask ? topTask.task_name : null
  });
});

// Fallback pour le frontend React (SPA)
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/build', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`🚀 Serveur démarré sur le port ${PORT}`);
  console.log(`📁 Base de données: ${path.join(__dirname, 'database.sqlite')}`);
});
