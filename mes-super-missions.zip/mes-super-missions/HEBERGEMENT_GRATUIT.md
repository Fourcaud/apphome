# 🆓 Hébergement Gratuit - Mes Super Missions

Voici les meilleures options gratuites pour héberger votre application.

---

## 🏆 Option Recommandée : Railway.app

**Pourquoi ?** Simple, rapide, base de données incluse, pas de carte bancaire requise.

### Limites gratuites
- 500 heures/mois (suffisant pour un usage familial)
- 1 Go de RAM
- Base de données SQLite incluse

### Étapes de déploiement

1. **Créer un compte** sur [railway.app](https://railway.app)

2. **Préparer le projet** (fichiers à modifier)

3. **Connecter GitHub** et déployer

---

## 🟣 Option 2 : Render.com

**Avantages** : Très simple, SSL gratuit, pas de carte bancaire

### Limites gratuites
- Le serveur "dort" après 15 min d'inactivité (redémarre en ~30 sec)
- 750 heures/mois
- Parfait pour usage familial

---

## 🔵 Option 3 : Fly.io

**Avantages** : Performant, données persistantes

### Limites gratuites
- 3 VMs partagées
- 3 Go de stockage
- Nécessite carte bancaire (mais pas débité)

---

## 🟢 Option 4 : Glitch.com

**Avantages** : Le plus simple, éditeur en ligne, idéal pour débutants

### Limites
- Dort après 5 min (réveil ~10 sec)
- Projets publics uniquement en gratuit

---

# 📘 Guide Détaillé : Déploiement sur Render.com

C'est l'option la plus simple sans aucune modification de code.

## Étape 1 : Créer un compte GitHub

1. Allez sur [github.com](https://github.com)
2. Créez un compte gratuit
3. Créez un nouveau repository appelé `mes-super-missions`

## Étape 2 : Uploader le code

1. Dans votre repository GitHub, cliquez sur "Add file" → "Upload files"
2. Glissez tous les fichiers du dossier `mes-super-missions`
3. Cliquez "Commit changes"

## Étape 3 : Créer un compte Render

1. Allez sur [render.com](https://render.com)
2. Cliquez "Get Started for Free"
3. Connectez-vous avec votre compte GitHub

## Étape 4 : Créer un Web Service

1. Dashboard → "New" → "Web Service"
2. Connectez votre repository `mes-super-missions`
3. Configurez :
   - **Name** : `mes-super-missions`
   - **Region** : Frankfurt (EU) pour la France
   - **Branch** : `main`
   - **Root Directory** : `backend`
   - **Runtime** : `Node`
   - **Build Command** : `npm install && cd ../frontend && npm install && npm run build`
   - **Start Command** : `node server.js`
   - **Instance Type** : Free

4. Cliquez "Create Web Service"

## Étape 5 : Attendre le déploiement

- Render va installer les dépendances et démarrer l'application
- Ça prend environ 5-10 minutes la première fois
- Vous obtiendrez une URL comme : `https://mes-super-missions.onrender.com`

## ⚠️ Note importante pour Render

Le serveur gratuit "dort" après 15 minutes d'inactivité. Le premier chargement peut prendre 30 secondes. C'est normal !

---

# 📘 Guide Détaillé : Déploiement sur Railway.app

## Étape 1 : Préparer les fichiers

Vous devez ajouter quelques fichiers de configuration.

### Créer `railway.json` à la racine :
```json
{
  "$schema": "https://railway.app/railway.schema.json",
  "build": {
    "builder": "NIXPACKS"
  },
  "deploy": {
    "startCommand": "cd backend && node server.js",
    "restartPolicyType": "ON_FAILURE"
  }
}
```

### Modifier `backend/server.js` ligne du static :
```javascript
// Remplacer cette ligne :
app.use(express.static(path.join(__dirname, '../frontend/build')));

// Par :
app.use(express.static(path.join(__dirname, '../frontend/build')));
```

## Étape 2 : Créer un compte

1. Allez sur [railway.app](https://railway.app)
2. "Login" avec GitHub

## Étape 3 : Nouveau projet

1. "New Project" → "Deploy from GitHub repo"
2. Sélectionnez votre repository
3. Railway détecte automatiquement Node.js
4. Cliquez "Deploy"

## Étape 4 : Générer un domaine

1. Allez dans Settings de votre service
2. "Generate Domain"
3. Vous obtenez : `https://mes-super-missions-xxx.up.railway.app`

---

# 📘 Guide Détaillé : Déploiement sur Glitch.com

Le plus simple de tous !

## Étape 1 : Créer un compte

1. Allez sur [glitch.com](https://glitch.com)
2. "Sign Up" (gratuit)

## Étape 2 : Importer le projet

1. "New Project" → "Import from GitHub"
2. Collez l'URL de votre repository GitHub
3. Glitch importe et démarre automatiquement

## Étape 3 : Configurer

1. Cliquez sur le fichier `.env` (ou créez-le)
2. Ajoutez :
```
PORT=3000
NODE_ENV=production
```

3. Dans `package.json` à la racine, assurez-vous d'avoir :
```json
{
  "scripts": {
    "start": "cd backend && node server.js"
  }
}
```

## Étape 4 : Accéder à l'application

Votre app est sur : `https://votre-projet.glitch.me`

---

# 🔄 Comparatif des solutions

| Plateforme | Facilité | Temps de réveil | Carte bancaire | Recommandation |
|------------|----------|-----------------|----------------|----------------|
| **Render** | ⭐⭐⭐⭐⭐ | ~30 sec | ❌ Non | 🥇 Meilleur choix |
| **Railway** | ⭐⭐⭐⭐ | Instantané | ❌ Non | 🥈 Plus rapide |
| **Glitch** | ⭐⭐⭐⭐⭐ | ~10 sec | ❌ Non | 🥉 Le plus simple |
| **Fly.io** | ⭐⭐⭐ | Instantané | ✅ Oui | Pour experts |

---

# 💡 Ma recommandation finale

## Pour un débutant : **Render.com**

1. Pas besoin de modifier le code
2. Interface simple
3. Gratuit sans carte bancaire
4. SSL automatique (https)

## Étapes résumées :

```
1. Créer compte GitHub → Uploader les fichiers
2. Créer compte Render → Connecter GitHub
3. New Web Service → Configurer → Deploy
4. Attendre 5 min → C'est en ligne ! 🎉
```

---

# ❓ FAQ

**Q: L'application dort, c'est gênant ?**
R: Pour un usage familial (quelques fois par jour), ce n'est pas un problème. Le premier chargement prend 30 secondes max.

**Q: Mes données sont-elles sauvegardées ?**
R: Oui ! La base de données SQLite est persistante sur toutes ces plateformes.

**Q: Puis-je utiliser mon propre nom de domaine ?**
R: Oui, toutes ces plateformes permettent d'ajouter un domaine personnalisé (même en gratuit).

**Q: C'est vraiment gratuit ?**
R: Oui, pour un usage familial ces offres gratuites sont largement suffisantes.

---

Bonne chance pour le déploiement ! 🚀
