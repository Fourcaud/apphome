import React, { useState, useEffect, useCallback } from 'react';
import { Star, Gift, CheckCircle, Clock, Trophy, User, Settings, Plus, Trash2, Edit2, X, Check, Zap, Crown, Lock, Eye, EyeOff, RefreshCw } from 'lucide-react';
import './App.css';

// Configuration API
const API_URL = process.env.REACT_APP_API_URL || '';

// Fetch helper
const api = {
  get: async (endpoint) => {
    const res = await fetch(`${API_URL}/api${endpoint}`);
    if (!res.ok) throw new Error('Erreur réseau');
    return res.json();
  },
  post: async (endpoint, data) => {
    const res = await fetch(`${API_URL}/api${endpoint}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (!res.ok) {
      const error = await res.json();
      throw new Error(error.error || 'Erreur réseau');
    }
    return res.json();
  },
  put: async (endpoint, data) => {
    const res = await fetch(`${API_URL}/api${endpoint}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (!res.ok) throw new Error('Erreur réseau');
    return res.json();
  },
  delete: async (endpoint) => {
    const res = await fetch(`${API_URL}/api${endpoint}`, { method: 'DELETE' });
    if (!res.ok) throw new Error('Erreur réseau');
    return res.json();
  }
};

// Liste étendue d'avatars
const AVATARS = [
  // Personnes
  '👶', '👧', '👦', '🧒', '👸', '🤴', '🧒🏻', '🧒🏼', '🧒🏽', '🧒🏾', '🧒🏿',
  '👧🏻', '👧🏼', '👧🏽', '👧🏾', '👧🏿', '👦🏻', '👦🏼', '👦🏽', '👦🏾', '👦🏿',
  // Super-héros
  '🦸‍♀️', '🦸‍♂️', '🦸', '🦹‍♀️', '🦹‍♂️', '🦹',
  // Fantaisie
  '🧙‍♀️', '🧙‍♂️', '🧚‍♀️', '🧚‍♂️', '🧜‍♀️', '🧜‍♂️', '🧝‍♀️', '🧝‍♂️',
  '👼', '🤖', '👽', '👻', '🎅', '🤶',
  // Animaux mignons
  '🦄', '🐱', '🐶', '🐰', '🐼', '🦊', '🦁', '🐯', '🐻', '🐨',
  '🐸', '🐵', '🦋', '🐝', '🐞', '🦖', '🦕', '🐲', '🦩', '🦜',
  '🐧', '🐥', '🦉', '🐬', '🐳', '🦈', '🐙', '🦑',
  // Objets fun
  '⭐', '🌟', '💫', '✨', '🌈', '☀️', '🌙', '⚡', '🔥', '💎',
  '🎈', '🎀', '🎭', '🎪', '🎨', '🎬', '🎤', '🎸', '🎹', '🥁'
];

// Liste d'icônes pour les tâches
const TASK_ICONS = [
  // Maison
  '🏠', '🛏️', '🧹', '🧺', '🧽', '🗑️', '🪣', '🧴', '🧻', '🪥',
  '🚿', '🛁', '🚽', '🪠', '🧼', '🪒', '🧯', '🔑', '🚪', '🪟',
  '🛋️', '🪑', '🛏️', '🖼️', '🪴', '🌱', '💐', '🌻',
  // Repas
  '🍽️', '🍳', '🥘', '🍲', '🥗', '🍕', '🍔', '🥪', '🌮', '🍜',
  '🥤', '🧃', '🥛', '☕', '🍵', '🧁', '🍰', '🍪', '🍫', '🍬',
  // École
  '📚', '📖', '📝', '✏️', '🖍️', '🎨', '📐', '📏', '🔬', '🔭',
  '💻', '🖥️', '⌨️', '🖱️', '📱', '🎒', '🏫', '🎓', '📓', '📒',
  // Sport & Activités
  '⚽', '🏀', '🏈', '⚾', '🎾', '🏐', '🏓', '🏸', '🥊', '🥋',
  '🚴', '🏊', '🤸', '🧘', '🎯', '🎳', '🎮', '🎲', '🧩', '🎪',
  // Nature & Animaux
  '🐕', '🐈', '🐠', '🐦', '🐹', '🌳', '🌲', '🌴', '🌵', '🍀',
  // Hygiène & Santé
  '🪥', '🧴', '💊', '🩹', '🌡️', '💉', '🩺', '❤️', '💪', '🧠',
  // Temps & Organisation
  '⏰', '⏱️', '📅', '📆', '✅', '❌', '⭐', '🌟', '🏆', '🎖️',
  // Divers
  '💰', '🎁', '📦', '✉️', '📬', '🔔', '🎵', '🎶', '🎤', '📸'
];

// Couleurs disponibles
const COLORS = [
  '#FF6B9D', '#4ECDC4', '#FFE66D', '#95E1D3', '#F38181', '#AA96DA',
  '#7B68EE', '#FF8C42', '#98D8C8', '#F7DC6F', '#BB8FCE', '#85C1E9',
  '#F1948A', '#82E0AA', '#F8B500', '#00CED1', '#FF6347', '#9370DB'
];

// Catégories
const CATEGORIES = [
  { id: 'maison', name: 'Maison', icon: '🏠' },
  { id: 'école', name: 'École', icon: '📚' },
  { id: 'hygiène', name: 'Hygiène', icon: '🧼' },
  { id: 'sport', name: 'Sport', icon: '⚽' },
  { id: 'autre', name: 'Autre', icon: '⭐' }
];

// Confetti component
const Confetti = ({ show }) => {
  if (!show) return null;
  
  const confettiPieces = Array.from({ length: 50 }, (_, i) => ({
    id: i,
    left: Math.random() * 100,
    delay: Math.random() * 0.5,
    duration: 1 + Math.random() * 2,
    color: COLORS[Math.floor(Math.random() * COLORS.length)],
  }));

  return (
    <div className="confetti-container">
      {confettiPieces.map((piece) => (
        <div
          key={piece.id}
          className="confetti-piece"
          style={{
            left: `${piece.left}%`,
            animationDelay: `${piece.delay}s`,
            animationDuration: `${piece.duration}s`,
            backgroundColor: piece.color,
          }}
        />
      ))}
    </div>
  );
};

// Icon Picker Component
const IconPicker = ({ icons, selected, onSelect, title }) => {
  const [search, setSearch] = useState('');
  
  return (
    <div className="icon-picker">
      <div className="icon-picker-grid">
        {icons.map((icon, index) => (
          <button
            key={index}
            type="button"
            className={`icon-option ${selected === icon ? 'selected' : ''}`}
            onClick={() => onSelect(icon)}
          >
            {icon}
          </button>
        ))}
      </div>
    </div>
  );
};

// Child Selection Screen
const ChildSelector = ({ children, onSelectChild, onAdminLogin, loading }) => {
  return (
    <div className="child-selector">
      <div className="selector-header">
        <div className="logo-container">
          <div className="logo-stars">
            <Star className="star star-1" />
            <Star className="star star-2" />
            <Star className="star star-3" />
          </div>
          <h1>Mes Super Missions</h1>
          <p className="subtitle">Qui va gagner des points aujourd'hui ?</p>
        </div>
      </div>
      
      {loading ? (
        <div className="loading">
          <RefreshCw className="spin" size={48} />
          <p>Chargement...</p>
        </div>
      ) : (
        <div className="children-grid">
          {children.map((child, index) => (
            <button
              key={child.id}
              className="child-card"
              onClick={() => onSelectChild(child)}
              style={{ 
                '--card-color': child.color,
                animationDelay: `${index * 0.1}s`
              }}
            >
              <div className="avatar-container">
                <span className="avatar">{child.avatar}</span>
                <div className="avatar-glow" />
              </div>
              <span className="child-name">{child.name}</span>
              <div className="points-preview">
                <Star className="mini-star" />
                <span>{child.points} points</span>
              </div>
            </button>
          ))}
        </div>
      )}
      
      <button className="admin-button" onClick={onAdminLogin}>
        <Settings size={20} />
        <span>Espace Parent</span>
      </button>
    </div>
  );
};

// Child Dashboard
const ChildDashboard = ({ child, tasks, rewards, pendingTasks, onCompleteTask, onClaimReward, onBack, childrenForLeaderboard }) => {
  const [activeTab, setActiveTab] = useState('missions');
  const [showConfetti, setShowConfetti] = useState(false);
  const [completedAnimation, setCompletedAnimation] = useState(null);

  const handleCompleteTask = async (task) => {
    setCompletedAnimation(task.id);
    setShowConfetti(true);
    await onCompleteTask(task);
    setTimeout(() => {
      setShowConfetti(false);
      setCompletedAnimation(null);
    }, 2000);
  };

  const childPendingTasks = pendingTasks.filter(t => t.child_id === child.id);
  const pendingTaskIds = childPendingTasks.map(pt => pt.task_id);
  const availableTasks = tasks.filter(task => !pendingTaskIds.includes(task.id));
  const sortedChildren = [...childrenForLeaderboard].sort((a, b) => b.points - a.points);

  return (
    <div className="child-dashboard" style={{ '--theme-color': child.color }}>
      <Confetti show={showConfetti} />
      
      <header className="child-header">
        <button className="back-button" onClick={onBack}>
          ← Retour
        </button>
        <div className="child-info">
          <span className="header-avatar">{child.avatar}</span>
          <span className="header-name">{child.name}</span>
        </div>
        <div className="points-display">
          <Star className="points-star" />
          <span className="points-value">{child.points}</span>
          <span className="points-label">points</span>
        </div>
      </header>

      <nav className="child-nav">
        <button 
          className={`nav-tab ${activeTab === 'missions' ? 'active' : ''}`}
          onClick={() => setActiveTab('missions')}
        >
          <Zap size={24} />
          <span>Missions</span>
        </button>
        <button 
          className={`nav-tab ${activeTab === 'rewards' ? 'active' : ''}`}
          onClick={() => setActiveTab('rewards')}
        >
          <Gift size={24} />
          <span>Récompenses</span>
        </button>
        <button 
          className={`nav-tab ${activeTab === 'leaderboard' ? 'active' : ''}`}
          onClick={() => setActiveTab('leaderboard')}
        >
          <Trophy size={24} />
          <span>Classement</span>
        </button>
      </nav>

      <main className="child-content">
        {activeTab === 'missions' && (
          <div className="missions-view">
            {childPendingTasks.length > 0 && (
              <section className="pending-section">
                <h2><Clock size={24} /> En attente de validation</h2>
                <div className="tasks-grid">
                  {childPendingTasks.map(pt => (
                    <div key={pt.id} className="task-card pending">
                      <span className="task-icon">{pt.task_icon}</span>
                      <span className="task-name">{pt.task_name}</span>
                      <div className="task-status">
                        <Clock size={16} />
                        <span>En attente...</span>
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}

            <section className="available-section">
              <h2><Zap size={24} /> Mes missions du jour</h2>
              {availableTasks.length === 0 ? (
                <div className="empty-tasks">
                  <span className="empty-icon">🎉</span>
                  <p>Bravo ! Tu as terminé toutes tes missions !</p>
                </div>
              ) : (
                <div className="tasks-grid">
                  {availableTasks.map(task => (
                    <div 
                      key={task.id} 
                      className={`task-card ${completedAnimation === task.id ? 'completing' : ''}`}
                    >
                      <span className="task-icon">{task.icon}</span>
                      <span className="task-name">{task.name}</span>
                      <div className="task-points">
                        <Star size={16} />
                        <span>+{task.points}</span>
                      </div>
                      <button 
                        className="complete-button"
                        onClick={() => handleCompleteTask(task)}
                      >
                        <CheckCircle size={20} />
                        <span>J'ai terminé !</span>
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </section>
          </div>
        )}

        {activeTab === 'rewards' && (
          <div className="rewards-view">
            <h2><Gift size={24} /> Mes récompenses</h2>
            <div className="rewards-grid">
              {rewards.map(reward => {
                const canClaim = child.points >= reward.cost;
                const progress = Math.min((child.points / reward.cost) * 100, 100);
                return (
                  <div 
                    key={reward.id} 
                    className={`reward-card ${canClaim ? 'available' : 'locked'}`}
                  >
                    <span className="reward-icon">{reward.icon}</span>
                    <span className="reward-name">{reward.name}</span>
                    <p className="reward-description">{reward.description}</p>
                    <div className="reward-cost">
                      <Star size={16} />
                      <span>{reward.cost} points</span>
                    </div>
                    <div className="progress-bar">
                      <div 
                        className="progress-fill" 
                        style={{ width: `${progress}%` }}
                      />
                    </div>
                    {canClaim ? (
                      <button 
                        className="claim-button"
                        onClick={() => onClaimReward(reward)}
                      >
                        <Gift size={20} />
                        <span>Obtenir !</span>
                      </button>
                    ) : (
                      <div className="points-needed">
                        Encore {reward.cost - child.points} points
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {activeTab === 'leaderboard' && (
          <div className="leaderboard-view">
            <h2><Trophy size={24} /> Classement</h2>
            <div className="leaderboard-list">
              {sortedChildren.map((c, index) => (
                <div 
                  key={c.id} 
                  className={`leaderboard-item ${c.id === child.id ? 'current' : ''}`}
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <div className="rank">
                    {index === 0 ? <Crown className="crown gold" /> : 
                     index === 1 ? <Crown className="crown silver" /> :
                     index === 2 ? <Crown className="crown bronze" /> :
                     <span className="rank-number">{index + 1}</span>}
                  </div>
                  <span className="leaderboard-avatar">{c.avatar}</span>
                  <span className="leaderboard-name">{c.name}</span>
                  <div className="leaderboard-points">
                    <Star size={18} />
                    <span>{c.points}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

// Admin Dashboard
const AdminDashboard = ({ 
  children, tasks, rewards, pendingTasks,
  onValidateTask, onRejectTask, onAddTask, onEditTask, onDeleteTask,
  onAddReward, onEditReward, onDeleteReward,
  onAddChild, onEditChild, onDeleteChild, onAdjustPoints,
  onChangePassword, onLogout, onRefresh
}) => {
  const [activeSection, setActiveSection] = useState('pending');
  const [editingItem, setEditingItem] = useState(null);
  const [showModal, setShowModal] = useState(null);
  const [newItem, setNewItem] = useState({});
  const [passwordData, setPasswordData] = useState({ current: '', new: '', confirm: '' });
  const [showPasswords, setShowPasswords] = useState({ current: false, new: false, confirm: false });
  const [passwordError, setPasswordError] = useState('');
  const [passwordSuccess, setPasswordSuccess] = useState('');

  const handleSaveTask = async () => {
    if (editingItem) {
      await onEditTask(editingItem.id, newItem);
    } else {
      await onAddTask(newItem);
    }
    setShowModal(null);
    setEditingItem(null);
    setNewItem({});
  };

  const handleSaveReward = async () => {
    if (editingItem) {
      await onEditReward(editingItem.id, newItem);
    } else {
      await onAddReward(newItem);
    }
    setShowModal(null);
    setEditingItem(null);
    setNewItem({});
  };

  const handleSaveChild = async () => {
    if (editingItem) {
      await onEditChild(editingItem.id, newItem);
    } else {
      await onAddChild(newItem);
    }
    setShowModal(null);
    setEditingItem(null);
    setNewItem({});
  };

  const handleChangePassword = async () => {
    setPasswordError('');
    setPasswordSuccess('');
    
    if (passwordData.new !== passwordData.confirm) {
      setPasswordError('Les nouveaux codes PIN ne correspondent pas');
      return;
    }
    
    if (passwordData.new.length < 4) {
      setPasswordError('Le code PIN doit contenir au moins 4 caractères');
      return;
    }
    
    try {
      await onChangePassword(passwordData.current, passwordData.new);
      setPasswordSuccess('Code PIN modifié avec succès !');
      setPasswordData({ current: '', new: '', confirm: '' });
      setTimeout(() => setPasswordSuccess(''), 3000);
    } catch (error) {
      setPasswordError(error.message);
    }
  };

  const openEditTask = (task) => {
    setEditingItem(task);
    setNewItem({ ...task });
    setShowModal('task');
  };

  const openEditReward = (reward) => {
    setEditingItem(reward);
    setNewItem({ ...reward });
    setShowModal('reward');
  };

  const openEditChild = (child) => {
    setEditingItem(child);
    setNewItem({ ...child });
    setShowModal('child');
  };

  return (
    <div className="admin-dashboard">
      <header className="admin-header">
        <h1><Settings size={28} /> Espace Parent</h1>
        <div className="admin-header-actions">
          <button className="refresh-button" onClick={onRefresh} title="Actualiser">
            <RefreshCw size={20} />
          </button>
          <button className="logout-button" onClick={onLogout}>
            Déconnexion
          </button>
        </div>
      </header>

      <nav className="admin-nav">
        <button 
          className={activeSection === 'pending' ? 'active' : ''}
          onClick={() => setActiveSection('pending')}
        >
          <Clock size={20} />
          <span>Validations</span>
          {pendingTasks.length > 0 && <span className="badge">{pendingTasks.length}</span>}
        </button>
        <button 
          className={activeSection === 'tasks' ? 'active' : ''}
          onClick={() => setActiveSection('tasks')}
        >
          <CheckCircle size={20} />
          <span>Tâches</span>
        </button>
        <button 
          className={activeSection === 'rewards' ? 'active' : ''}
          onClick={() => setActiveSection('rewards')}
        >
          <Gift size={20} />
          <span>Récompenses</span>
        </button>
        <button 
          className={activeSection === 'children' ? 'active' : ''}
          onClick={() => setActiveSection('children')}
        >
          <User size={20} />
          <span>Enfants</span>
        </button>
        <button 
          className={activeSection === 'settings' ? 'active' : ''}
          onClick={() => setActiveSection('settings')}
        >
          <Lock size={20} />
          <span>Sécurité</span>
        </button>
      </nav>

      <main className="admin-content">
        {activeSection === 'pending' && (
          <section className="admin-section">
            <h2>Tâches en attente de validation</h2>
            {pendingTasks.length === 0 ? (
              <div className="empty-state">
                <CheckCircle size={48} />
                <p>Aucune tâche en attente</p>
              </div>
            ) : (
              <div className="pending-list">
                {pendingTasks.map(pt => (
                  <div key={pt.id} className="pending-item">
                    <div className="pending-info">
                      <span className="pending-avatar">{pt.child_avatar}</span>
                      <div className="pending-details">
                        <strong>{pt.child_name}</strong>
                        <span>{pt.task_icon} {pt.task_name}</span>
                        <span className="pending-points">+{pt.task_points} points</span>
                      </div>
                    </div>
                    <div className="pending-actions">
                      <button 
                        className="validate-btn"
                        onClick={() => onValidateTask(pt)}
                      >
                        <Check size={20} />
                        Valider
                      </button>
                      <button 
                        className="reject-btn"
                        onClick={() => onRejectTask(pt)}
                      >
                        <X size={20} />
                        Refuser
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>
        )}

        {activeSection === 'tasks' && (
          <section className="admin-section">
            <div className="section-header">
              <h2>Gestion des tâches</h2>
              <button 
                className="add-button"
                onClick={() => {
                  setEditingItem(null);
                  setNewItem({ name: '', points: 10, category: 'maison', icon: '📋', frequency: 'quotidienne' });
                  setShowModal('task');
                }}
              >
                <Plus size={20} />
                Ajouter
              </button>
            </div>
            <div className="items-list">
              {tasks.map(task => (
                <div key={task.id} className="item-row">
                  <span className="item-icon">{task.icon}</span>
                  <div className="item-info">
                    <strong>{task.name}</strong>
                    <span>{task.points} points • {task.category} • {task.frequency}</span>
                  </div>
                  <div className="item-actions">
                    <button onClick={() => openEditTask(task)}><Edit2 size={18} /></button>
                    <button onClick={() => onDeleteTask(task.id)}><Trash2 size={18} /></button>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        {activeSection === 'rewards' && (
          <section className="admin-section">
            <div className="section-header">
              <h2>Gestion des récompenses</h2>
              <button 
                className="add-button"
                onClick={() => {
                  setEditingItem(null);
                  setNewItem({ name: '', cost: 50, icon: '🎁', description: '' });
                  setShowModal('reward');
                }}
              >
                <Plus size={20} />
                Ajouter
              </button>
            </div>
            <div className="items-list">
              {rewards.map(reward => (
                <div key={reward.id} className="item-row">
                  <span className="item-icon">{reward.icon}</span>
                  <div className="item-info">
                    <strong>{reward.name}</strong>
                    <span>{reward.cost} points • {reward.description}</span>
                  </div>
                  <div className="item-actions">
                    <button onClick={() => openEditReward(reward)}><Edit2 size={18} /></button>
                    <button onClick={() => onDeleteReward(reward.id)}><Trash2 size={18} /></button>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        {activeSection === 'children' && (
          <section className="admin-section">
            <div className="section-header">
              <h2>Gestion des enfants</h2>
              <button 
                className="add-button"
                onClick={() => {
                  setEditingItem(null);
                  setNewItem({ name: '', avatar: '👶', points: 0, color: '#FF6B9D' });
                  setShowModal('child');
                }}
              >
                <Plus size={20} />
                Ajouter
              </button>
            </div>
            <div className="items-list">
              {children.map(child => (
                <div key={child.id} className="item-row child-row">
                  <span className="item-icon child-avatar" style={{ backgroundColor: child.color }}>{child.avatar}</span>
                  <div className="item-info">
                    <strong>{child.name}</strong>
                    <span>{child.points} points</span>
                  </div>
                  <div className="points-adjust">
                    <button onClick={() => onAdjustPoints(child.id, -10)}>-10</button>
                    <button onClick={() => onAdjustPoints(child.id, -1)}>-1</button>
                    <button onClick={() => onAdjustPoints(child.id, 1)}>+1</button>
                    <button onClick={() => onAdjustPoints(child.id, 10)}>+10</button>
                  </div>
                  <div className="item-actions">
                    <button onClick={() => openEditChild(child)}><Edit2 size={18} /></button>
                    <button onClick={() => onDeleteChild(child.id)}><Trash2 size={18} /></button>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        {activeSection === 'settings' && (
          <section className="admin-section">
            <h2>Changer le code PIN</h2>
            <div className="password-form">
              <div className="form-group">
                <label>Code PIN actuel</label>
                <div className="password-input-wrapper">
                  <input 
                    type={showPasswords.current ? 'text' : 'password'}
                    value={passwordData.current}
                    onChange={e => setPasswordData({...passwordData, current: e.target.value})}
                    placeholder="Entrez le code actuel"
                  />
                  <button 
                    type="button" 
                    className="toggle-password"
                    onClick={() => setShowPasswords({...showPasswords, current: !showPasswords.current})}
                  >
                    {showPasswords.current ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </div>
              <div className="form-group">
                <label>Nouveau code PIN</label>
                <div className="password-input-wrapper">
                  <input 
                    type={showPasswords.new ? 'text' : 'password'}
                    value={passwordData.new}
                    onChange={e => setPasswordData({...passwordData, new: e.target.value})}
                    placeholder="Entrez le nouveau code"
                  />
                  <button 
                    type="button" 
                    className="toggle-password"
                    onClick={() => setShowPasswords({...showPasswords, new: !showPasswords.new})}
                  >
                    {showPasswords.new ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </div>
              <div className="form-group">
                <label>Confirmer le nouveau code PIN</label>
                <div className="password-input-wrapper">
                  <input 
                    type={showPasswords.confirm ? 'text' : 'password'}
                    value={passwordData.confirm}
                    onChange={e => setPasswordData({...passwordData, confirm: e.target.value})}
                    placeholder="Confirmez le nouveau code"
                  />
                  <button 
                    type="button" 
                    className="toggle-password"
                    onClick={() => setShowPasswords({...showPasswords, confirm: !showPasswords.confirm})}
                  >
                    {showPasswords.confirm ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </div>
              {passwordError && <div className="error-message">{passwordError}</div>}
              {passwordSuccess && <div className="success-message">{passwordSuccess}</div>}
              <button className="save-password-btn" onClick={handleChangePassword}>
                <Lock size={18} />
                Changer le code PIN
              </button>
            </div>
          </section>
        )}
      </main>

      {/* Modal Tâche */}
      {showModal === 'task' && (
        <div className="modal-overlay" onClick={() => setShowModal(null)}>
          <div className="modal modal-large" onClick={e => e.stopPropagation()}>
            <h3>{editingItem ? 'Modifier la tâche' : 'Nouvelle tâche'}</h3>
            <div className="form-group">
              <label>Nom</label>
              <input 
                type="text" 
                value={newItem.name || ''} 
                onChange={e => setNewItem({...newItem, name: e.target.value})}
                placeholder="Ex: Ranger sa chambre"
              />
            </div>
            <div className="form-row">
              <div className="form-group">
                <label>Points</label>
                <input 
                  type="number" 
                  value={newItem.points || 0} 
                  onChange={e => setNewItem({...newItem, points: parseInt(e.target.value) || 0})}
                />
              </div>
              <div className="form-group">
                <label>Catégorie</label>
                <select 
                  value={newItem.category || 'maison'} 
                  onChange={e => setNewItem({...newItem, category: e.target.value})}
                >
                  {CATEGORIES.map(cat => (
                    <option key={cat.id} value={cat.id}>{cat.icon} {cat.name}</option>
                  ))}
                </select>
              </div>
              <div className="form-group">
                <label>Fréquence</label>
                <select 
                  value={newItem.frequency || 'quotidienne'} 
                  onChange={e => setNewItem({...newItem, frequency: e.target.value})}
                >
                  <option value="quotidienne">Quotidienne</option>
                  <option value="hebdomadaire">Hebdomadaire</option>
                  <option value="ponctuelle">Ponctuelle</option>
                </select>
              </div>
            </div>
            <div className="form-group">
              <label>Icône (clique pour choisir)</label>
              <div className="selected-icon-preview">
                Sélectionné : <span className="big-icon">{newItem.icon || '📋'}</span>
              </div>
              <IconPicker 
                icons={TASK_ICONS} 
                selected={newItem.icon} 
                onSelect={icon => setNewItem({...newItem, icon})}
              />
            </div>
            <div className="modal-actions">
              <button className="cancel-btn" onClick={() => setShowModal(null)}>Annuler</button>
              <button className="save-btn" onClick={handleSaveTask}>Enregistrer</button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Récompense */}
      {showModal === 'reward' && (
        <div className="modal-overlay" onClick={() => setShowModal(null)}>
          <div className="modal modal-large" onClick={e => e.stopPropagation()}>
            <h3>{editingItem ? 'Modifier la récompense' : 'Nouvelle récompense'}</h3>
            <div className="form-group">
              <label>Nom</label>
              <input 
                type="text" 
                value={newItem.name || ''} 
                onChange={e => setNewItem({...newItem, name: e.target.value})}
                placeholder="Ex: Sortie cinéma"
              />
            </div>
            <div className="form-group">
              <label>Coût en points</label>
              <input 
                type="number" 
                value={newItem.cost || 0} 
                onChange={e => setNewItem({...newItem, cost: parseInt(e.target.value) || 0})}
              />
            </div>
            <div className="form-group">
              <label>Description</label>
              <textarea 
                value={newItem.description || ''} 
                onChange={e => setNewItem({...newItem, description: e.target.value})}
                placeholder="Description de la récompense"
              />
            </div>
            <div className="form-group">
              <label>Icône (clique pour choisir)</label>
              <div className="selected-icon-preview">
                Sélectionné : <span className="big-icon">{newItem.icon || '🎁'}</span>
              </div>
              <IconPicker 
                icons={TASK_ICONS} 
                selected={newItem.icon} 
                onSelect={icon => setNewItem({...newItem, icon})}
              />
            </div>
            <div className="modal-actions">
              <button className="cancel-btn" onClick={() => setShowModal(null)}>Annuler</button>
              <button className="save-btn" onClick={handleSaveReward}>Enregistrer</button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Enfant */}
      {showModal === 'child' && (
        <div className="modal-overlay" onClick={() => setShowModal(null)}>
          <div className="modal modal-large" onClick={e => e.stopPropagation()}>
            <h3>{editingItem ? "Modifier l'enfant" : 'Nouvel enfant'}</h3>
            <div className="form-group">
              <label>Prénom</label>
              <input 
                type="text" 
                value={newItem.name || ''} 
                onChange={e => setNewItem({...newItem, name: e.target.value})}
                placeholder="Ex: Emma"
              />
            </div>
            {!editingItem && (
              <div className="form-group">
                <label>Points de départ</label>
                <input 
                  type="number" 
                  value={newItem.points || 0} 
                  onChange={e => setNewItem({...newItem, points: parseInt(e.target.value) || 0})}
                />
              </div>
            )}
            <div className="form-group">
              <label>Avatar (clique pour choisir)</label>
              <div className="selected-icon-preview">
                Sélectionné : <span className="big-icon">{newItem.avatar || '👶'}</span>
              </div>
              <IconPicker 
                icons={AVATARS} 
                selected={newItem.avatar} 
                onSelect={avatar => setNewItem({...newItem, avatar})}
              />
            </div>
            <div className="form-group">
              <label>Couleur</label>
              <div className="color-picker">
                {COLORS.map(color => (
                  <button 
                    key={color}
                    type="button"
                    className={newItem.color === color ? 'selected' : ''}
                    style={{ backgroundColor: color }}
                    onClick={() => setNewItem({...newItem, color: color})}
                  />
                ))}
              </div>
            </div>
            <div className="modal-actions">
              <button className="cancel-btn" onClick={() => setShowModal(null)}>Annuler</button>
              <button className="save-btn" onClick={handleSaveChild}>Enregistrer</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// PIN Entry
const PinEntry = ({ onSuccess, onCancel }) => {
  const [pin, setPin] = useState('');
  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(false);

  const verifyPin = async (pinToVerify) => {
    setLoading(true);
    try {
      const result = await api.post('/auth/verify-pin', { pin: pinToVerify });
      if (result.success) {
        onSuccess();
      }
    } catch (err) {
      setError(true);
      setTimeout(() => {
        setPin('');
        setError(false);
      }, 500);
    } finally {
      setLoading(false);
    }
  };

  const handleDigit = (digit) => {
    if (pin.length < 8 && !loading) {
      const newPin = pin + digit;
      setPin(newPin);
      setError(false);
    }
  };

  const handleDelete = () => {
    if (!loading) {
      setPin(pin.slice(0, -1));
      setError(false);
    }
  };

  const handleSubmit = () => {
    if (pin.length >= 4 && !loading) {
      verifyPin(pin);
    }
  };

  return (
    <div className="pin-entry">
      <button className="back-button" onClick={onCancel}>← Retour</button>
      <h2>Code Parent</h2>
      <p>Entrez votre code PIN</p>
      <div className={`pin-display ${error ? 'error' : ''}`}>
        {pin.split('').map((_, i) => (
          <div key={i} className="pin-dot filled" />
        ))}
        {Array.from({ length: Math.max(0, 4 - pin.length) }).map((_, i) => (
          <div key={`empty-${i}`} className="pin-dot" />
        ))}
      </div>
      <div className="pin-pad">
        {[1, 2, 3, 4, 5, 6, 7, 8, 9, '⌫', 0, '✓'].map((digit, i) => (
          <button
            key={i}
            className={digit === '✓' ? 'submit-pin' : ''}
            onClick={() => {
              if (digit === '⌫') handleDelete();
              else if (digit === '✓') handleSubmit();
              else handleDigit(digit.toString());
            }}
            disabled={loading || (digit === '✓' && pin.length < 4)}
          >
            {digit}
          </button>
        ))}
      </div>
    </div>
  );
};

// Main App
export default function App() {
  const [view, setView] = useState('selector');
  const [selectedChild, setSelectedChild] = useState(null);
  const [children, setChildren] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [rewards, setRewards] = useState([]);
  const [pendingTasks, setPendingTasks] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [childrenData, tasksData, rewardsData, pendingData] = await Promise.all([
        api.get('/children'),
        api.get('/tasks'),
        api.get('/rewards'),
        api.get('/pending-tasks')
      ]);
      setChildren(childrenData);
      setTasks(tasksData);
      setRewards(rewardsData);
      setPendingTasks(pendingData);
    } catch (error) {
      console.error('Erreur de chargement:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Mettre à jour selectedChild quand children change
  useEffect(() => {
    if (selectedChild) {
      const updated = children.find(c => c.id === selectedChild.id);
      if (updated) {
        setSelectedChild(updated);
      }
    }
  }, [children, selectedChild]);

  const handleSelectChild = (child) => {
    setSelectedChild(child);
    setView('child');
  };

  const handleCompleteTask = async (task) => {
    try {
      await api.post('/pending-tasks', { child_id: selectedChild.id, task_id: task.id });
      await loadData();
    } catch (error) {
      console.error('Erreur:', error);
    }
  };

  const handleValidateTask = async (pendingTask) => {
    try {
      await api.post(`/pending-tasks/${pendingTask.id}/validate`);
      await loadData();
    } catch (error) {
      console.error('Erreur:', error);
    }
  };

  const handleRejectTask = async (pendingTask) => {
    try {
      await api.post(`/pending-tasks/${pendingTask.id}/reject`);
      await loadData();
    } catch (error) {
      console.error('Erreur:', error);
    }
  };

  const handleClaimReward = async (reward) => {
    if (selectedChild && selectedChild.points >= reward.cost) {
      try {
        const result = await api.post(`/rewards/${reward.id}/claim`, { child_id: selectedChild.id });
        await loadData();
        alert(`🎉 Bravo ! Tu as obtenu : ${reward.name}`);
      } catch (error) {
        console.error('Erreur:', error);
        alert('Erreur lors de la réclamation');
      }
    }
  };

  const handleAddTask = async (task) => {
    await api.post('/tasks', task);
    await loadData();
  };

  const handleEditTask = async (id, updates) => {
    await api.put(`/tasks/${id}`, updates);
    await loadData();
  };

  const handleDeleteTask = async (id) => {
    if (window.confirm('Supprimer cette tâche ?')) {
      await api.delete(`/tasks/${id}`);
      await loadData();
    }
  };

  const handleAddReward = async (reward) => {
    await api.post('/rewards', reward);
    await loadData();
  };

  const handleEditReward = async (id, updates) => {
    await api.put(`/rewards/${id}`, updates);
    await loadData();
  };

  const handleDeleteReward = async (id) => {
    if (window.confirm('Supprimer cette récompense ?')) {
      await api.delete(`/rewards/${id}`);
      await loadData();
    }
  };

  const handleAddChild = async (child) => {
    await api.post('/children', child);
    await loadData();
  };

  const handleEditChild = async (id, updates) => {
    await api.put(`/children/${id}`, updates);
    await loadData();
  };

  const handleDeleteChild = async (id) => {
    if (window.confirm('Supprimer cet enfant et tout son historique ?')) {
      await api.delete(`/children/${id}`);
      await loadData();
    }
  };

  const handleAdjustPoints = async (childId, amount) => {
    await api.post(`/children/${childId}/adjust-points`, { amount });
    await loadData();
  };

  const handleChangePassword = async (currentPin, newPin) => {
    return api.post('/auth/change-pin', { currentPin, newPin });
  };

  return (
    <>
      {view === 'selector' && (
        <ChildSelector 
          children={children}
          onSelectChild={handleSelectChild}
          onAdminLogin={() => setView('pin')}
          loading={loading}
        />
      )}

      {view === 'pin' && (
        <PinEntry 
          onSuccess={() => setView('admin')}
          onCancel={() => setView('selector')}
        />
      )}

      {view === 'child' && selectedChild && (
        <ChildDashboard
          child={selectedChild}
          tasks={tasks}
          rewards={rewards}
          pendingTasks={pendingTasks}
          childrenForLeaderboard={children}
          onCompleteTask={handleCompleteTask}
          onClaimReward={handleClaimReward}
          onBack={() => {
            setSelectedChild(null);
            setView('selector');
          }}
        />
      )}

      {view === 'admin' && (
        <AdminDashboard
          children={children}
          tasks={tasks}
          rewards={rewards}
          pendingTasks={pendingTasks}
          onValidateTask={handleValidateTask}
          onRejectTask={handleRejectTask}
          onAddTask={handleAddTask}
          onEditTask={handleEditTask}
          onDeleteTask={handleDeleteTask}
          onAddReward={handleAddReward}
          onEditReward={handleEditReward}
          onDeleteReward={handleDeleteReward}
          onAddChild={handleAddChild}
          onEditChild={handleEditChild}
          onDeleteChild={handleDeleteChild}
          onAdjustPoints={handleAdjustPoints}
          onChangePassword={handleChangePassword}
          onLogout={() => setView('selector')}
          onRefresh={loadData}
        />
      )}
    </>
  );
}
