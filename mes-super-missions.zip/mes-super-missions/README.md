# ⭐ Mes Super Missions

Application de gestion de tâches et récompenses pour enfants.

![Stars](https://img.shields.io/badge/Pour-Enfants-FF6B9D)
![License](https://img.shields.io/badge/License-MIT-blue)

## 🎯 Fonctionnalités

### Pour les enfants 👶
- Interface colorée et intuitive
- Voir les missions disponibles
- Marquer les tâches comme terminées
- Gagner des points
- Échanger les points contre des récompenses
- Classement entre frères et sœurs

### Pour les parents 👨‍👩‍👧‍👦
- Valider les tâches effectuées
- Créer/modifier les tâches et récompenses
- Gérer les profils des enfants
- Ajuster les points manuellement
- Changer le code PIN de sécurité

## 🚀 Déploiement rapide sur Render.com (Gratuit)

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy)

### Étapes :

1. **Fork** ce repository sur GitHub
2. Créez un compte sur [render.com](https://render.com)
3. "New" → "Web Service" → Connectez votre GitHub
4. Sélectionnez ce repository
5. Configuration automatique grâce au fichier `render.yaml`
6. Cliquez "Create Web Service"
7. Attendez 5 minutes... C'est en ligne ! 🎉

## 🔐 Accès

- **Code PIN par défaut** : `1234`
- ⚠️ Changez-le immédiatement dans Espace Parent → Sécurité

## 💻 Installation locale

```bash
# Cloner
git clone https://github.com/votre-nom/mes-super-missions.git
cd mes-super-missions

# Installer
cd backend && npm install
cd ../frontend && npm install

# Lancer le backend
cd ../backend && node server.js

# Dans un autre terminal, lancer le frontend
cd frontend && npm start
```

## 📁 Structure

```
mes-super-missions/
├── backend/          # API Node.js + Express + SQLite
│   ├── server.js
│   └── database.sqlite (créé automatiquement)
├── frontend/         # React
│   ├── src/
│   └── public/
├── package.json      # Scripts de déploiement
└── render.yaml       # Configuration Render
```

## 🛠️ Technologies

- **Frontend** : React, CSS3
- **Backend** : Node.js, Express
- **Base de données** : SQLite (better-sqlite3)
- **Authentification** : bcryptjs

## 📝 License

MIT - Utilisez librement pour votre famille !

---

Fait avec ❤️ pour les familles
